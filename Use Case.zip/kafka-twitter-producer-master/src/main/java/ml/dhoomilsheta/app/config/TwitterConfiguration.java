package ml.dhoomilsheta.app.config;

public class TwitterConfiguration {
    public static final String CONSUMER_KEY = "qAUM1CSDp4OgvtpeZHxlHxVFC";
    public static final String CONSUMER_SECRET = "GAHUcpA7niK3ojABbMCUJUx9cO3NtttUD1unqClAV8OosQhwnE";
    public static final String ACCESS_TOKEN = "1261220958356078598-7TrYvwv33FDVI1EWRZdtIXOYjrbPma";
    public static final String TOKEN_SECRET = "TiueAQBPFiHDrzCT0HGLDixfHrrRQLQfqkZwWqJAbWrXz";
    public static final String HASHTAG = "#Covid-19";
}
